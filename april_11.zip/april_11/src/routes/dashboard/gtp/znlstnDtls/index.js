/**
 * Data Table
 */
import React from 'react';
import { connect } from 'react-redux'; // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component 

import IconButton from '@material-ui/core/IconButton';
//axios call
import axios from 'axios';

import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';

// page title bar
import PageTitleBar from 'Components/PageTitleBar/PageTitleBar';

// rct card box
import { RctCard, RctCardContent } from 'Components/RctCard'; 

// intl messages
import IntlMessages from 'Util/IntlMessages';
import NumberClass from 'Util/NumberClass';

//Reloadable card
import {WatchesWidget} from "Components/Widgets";

//Bootstrap datatable custom cell style
import BootstrapTable  from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import ToolkitProvider, { Search } from 'react-bootstrap-table2-toolkit';
import cellEditFactory from 'react-bootstrap-table2-editor';
//font-awesome icon
import "font-awesome/css/font-awesome.css";

// For Tab
import Paper from '@material-ui/core/Paper';

import Spinner from 'Util/Spinner';


import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import NoSsr from '@material-ui/core/NoSsr';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';

//For Drop Down menu


///////////////////
import Toolbar from '@material-ui/core/Toolbar';
import MenuIcon from '@material-ui/icons/Menu';
import AccountCircle from '@material-ui/icons/AccountCircle';
import Switch from '@material-ui/core/Switch';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormGroup from '@material-ui/core/FormGroup';
import MenuItem from '@material-ui/core/MenuItem';
import Menu from '@material-ui/core/Menu';
////////////////////////

const { SearchBar, ClearSearchButton } = Search;


function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 8 * 3 }}>
      {props.children}
    </Typography>
  );
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired,
};

function LinkTab(props) {
  return <Tab component="a" onClick={event => event.preventDefault()} {...props} />;
}

 const styles = theme => ({
  customTab: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
  },
  grow: {
    flexGrow: 1,
  },
  menuButton: {
    marginLeft: -12,
    marginRight: 20,
  },
});  


class ZonalNStationDtls extends React.Component {
		 		  
		  state = {
				value: this.props.match.params.operationStatus,
				zone: "all",
		  };

		  handleChange = (event, value) => {
				if (typeof value != "string"){
					return;
				}
				this.setState({ value });
			};			

		render() {
		
	const productsPicking = [ 
		{stationName: "Station A", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Jackson", runTime: "21 hrs",dwellTime: "0 Sec", taskUnit: 2000, throughput: 1800, productivity: 80 },
		{stationName: "Station B", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "William Doyle", runTime: "21 hrs",dwellTime: "+1 Sec",  taskUnit: 2000, throughput: 1800, productivity: 80 },
		{stationName: "Station C", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Miguel Schmidth", runTime: "21 hrs", dwellTime: "+10 Sec", taskUnit: 2000, throughput: 1800, productivity: 80 },
		{stationName: "Station D", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Aaron varun", runTime: "21 hrs", dwellTime: "-15 Sec", taskUnit: 2000, throughput: 1800, productivity: 80 }
	];
		
	const productsCnsolidtng = [ 
		{stationName: "Station A", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Abc Consolidating", runTime: "21 hrs", taskUnit: 2000, throughput: 1800, productivity: 80, dwellTime: "0 Sec" },
		{stationName: "Station A", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Abc Consolidating", runTime: "21 hrs", taskUnit: 2000, throughput: 1800, productivity: 80, dwellTime: "0 Sec" },
		{stationName: "Station A", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Abc Consolidating", runTime: "21 hrs", taskUnit: 2000, throughput: 1800, productivity: 80, dwellTime: "0 Sec" }
	];
		
	const productsDcntng = [ 
		{stationName: "Station A", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Abc Decanting", runTime: "21 hrs", taskUnit: 2000, throughput: 1800, productivity: 80, dwellTime: "0 Sec" },
		{stationName: "Station A", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Abc Decanting", runTime: "21 hrs", taskUnit: 2000, throughput: 1800, productivity: 80, dwellTime: "0 Sec" },
		{stationName: "Station A", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Abc Decanting", runTime: "21 hrs", taskUnit: 2000, throughput: 1800, productivity: 80, dwellTime: "0 Sec" }
	];
		
		
	const productsCyclkCnt = [ 
		{stationName: "Station A", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Abc CyclicCount", runTime: "21 hrs", taskUnit: 2000, throughput: 1800, productivity: 80, exceptionType: "Medium" },
		{stationName: "Station A", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Abc CyclicCount", runTime: "21 hrs", taskUnit: 2000, throughput: 1800, productivity: 80, exceptionType: "Medium" },
		{stationName: "Station A", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Abc CyclicCount", runTime: "21 hrs", taskUnit: 2000, throughput: 1800, productivity: 80, exceptionType: "Medium" }
	];
	
		const selectOptions = () => {
			return (
						
			  <div className= "customFilter">
				<button>
					<span class="fa fa-sliders" aria-hidden="true"></span>
				</button>
			  </div>
			);
		}
	
		const columns = [
			{
				dataField: 'stationName',
				text: 'Station Name',
				sort: true,
							
			},	
			{
				dataField: 'stationStatus',
				text: 'Station Status',
				sort: true,
				
			},
			{
				dataField: 'stnOvrlRunTime',
				text: 'Station Overall Run Time',
				sort: true,
				
			},
			{
				dataField: 'utilization',
				text: 'Utilization',
				sort: true
			},
			{
				dataField: 'operatorName',
				text: 'Operator Name',
				sort: true
			},
			{
				dataField: 'runTime',
				text: 'Run Time',
				sort: true
			},
			{
				dataField: 'dwellTime',
				text: 'Dwell Time',
				sort: true
			},
			{
				dataField: 'taskUnit',
				text: 'Task/Units',
				sort: true
			},
			{
				dataField: 'throughput',
				text: 'Throughput',
				sort: true
			},
			{
				dataField: 'productivity',
				text: 'Productivity',
				sort: true
			}
		];
		

		/* const selectRow = {
		  mode: 'checkbox',
		  clickToSelect: true
		}; */
		
		const headerClasses = {
		  mode: 'checkbox',
		  clickToSelect: true
		};
		
		const cellEdit = {
		  mode: 'click'
		};


		const { classes } = this.props;
		const { value } = this.state;
		const labels = ["Picking", "Consolidation", "Decanting", "Cycle Count"];
		
		const ReloadButton = () => {
			return (
			
			
			  <div  className="customReload">
				<button>
					<span class="fa fa-refresh" aria-hidden="true"></span>
				</button>
			  </div>
			);
		  };
		  
		  const Filter = () => {
			return (
						
			  <div className= "customFilter">
				<button>
					<span class="fa fa-sliders" aria-hidden="true"></span>
				</button>
			  </div>
			);
		  };
		  
		  const Search =() => {
			return (
						
			  <div className= "customSearch">
				<button>
					<span class="fa fa-search" aria-hidden="true"></span>
				</button>
			  </div>
			);
		  };
		 
		 const MenuIcon =() => {
			return (
						
			  <div className= "customMenu">
				<button>					
					<span class="fa fa-ellipsis-v" aria-hidden="true"></span>
					
				</button>
			  </div>
			);
		};
		  
		return(
		
		 <NoSsr>
        <div className={"customTab"}>		
          {(value === "Picking" || value === "Consolidation" || value === "Decanting" || value === "Cycle Count") && <TabContainer>
					
						<ToolkitProvider
							  keyField="id"
							   
							  
							>
							  {
								props => (																					
							<div>
								<div>
									<div className= "headerLeft">
										<div className="customTablebreadcrumb">
											Breadcrumb/breadcrumb
										</div>
										<div className="customTableHeader">
											Zonal And Station Details
										</div>
									</div>
									<div className="headerRight">
										<div><ReloadButton { ...props.searchProps } /></div>
										<div><Filter { ...props.searchProps } /></div>
										<div><Search { ...props.searchProps } /></div>
										<div><MenuIcon { ...props.searchProps } /></div>
									</div>
									
								</div>								
								<div className="barAndTable">	
								<AppBar position="static" className="customAppBar" style={{fontColor: '#647C72', backgroundColor: '#647C72'}}>
								<div className="tabAndDd">
									<div className="customTabLabels">
										<Tabs value={value} onChange={this.handleChange} className="customAppBar" >
										{labels && labels.map((label, key) => (
											<Tab style={{textTransform: 'uppercase'}} value={label} label={label} />
										))}
										</Tabs>
									</div>
										
									<div className="customDd text-right">
										<FormControl>
											<Select
											value={this.state.zone}
											onChange={this.handleChange}
											name="zone"
											IconComponent={props => (
												<i {...props} className={`material-icons ${props.className}`}>
												  keyboard_arrow_down
												</i>
											)}
											>
											<MenuItem value="all"><em>ALL ZONES</em></MenuItem>
											<MenuItem value={10}>Zone 1</MenuItem>
											<MenuItem value={20}>Zone 2</MenuItem>
											<MenuItem value={30}>Zone 3</MenuItem>
											</Select>
									</FormControl>
									</div>
								</div>
								
								</AppBar>
							
								
								
		
								<BootstrapTable
									keyField="id"
									data={ productsPicking } 
									columns={ columns } 									
									//selectRow={ selectRow }
									//cellEdit={ cellEditFactory({ mode: 'dbclick' }) }
									headerClasses={ headerClasses }
									bordered={ false }
								/>
									{/* <TableHeaderColumn dataField='id' isKey={ true } dataSort={ true }>Product ID</TableHeaderColumn>
									<TableHeaderColumn dataField='name' dataSort={ true }>Product Name</TableHeaderColumn>
									<TableHeaderColumn dataField='price'>Product Price</TableHeaderColumn> 
								</BootstrapTable>*/}
							</div> 
						</div>								  
								)
							  }
						</ToolkitProvider>					
		  </TabContainer>}
          
        </div>
      </NoSsr> 
		
			
			);
		}
}

export default ZonalNStationDtls;

