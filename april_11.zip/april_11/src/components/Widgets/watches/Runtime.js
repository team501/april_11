import React, {Component} from 'react';
import Grid from '@material-ui/core/Grid';
import { connect } from 'react-redux'; // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component 

//json
import json from 'JsnCnfg/MngEqpmnt/UntSrtrMnDshbrd/IndvdlSrtrDtls/watchesJson';

// intl messages
import IntlMessages from 'Util/IntlMessages';

//watch images
import Runtime from '../../../assets/img/runtime_icon.png';
import Total from '../../../assets/img/Total_icon.png';
import Stops from '../../../assets/img/Total_icon-03.png';

//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';

import {graphQlURLPrd} from '../../../services/Config.js';
import Spinner from 'Util/Spinner';

const imageRuntime = {
		width: '65px',
		marginTop: '5%'
}

const textStyle = {
	fontSize: '24px',
	padding: '5px'
}

const hrsStyle = {
	fontSize: '35px', 
	color: json.container.leftSegment.components[0].options.color
}
const hrsStyleCB = {
	fontSize: '35px', 
	color: '#5f5fb3'
}

class index extends Component { 
	
	constructor(props) {
		super(props);
		this.state = { 
					   value: "",
					   isLoading:true
					 };
	}
	
	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getRecentOrders();
	}

	//Comparing props and triggering refresh 
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.getRecentOrders();
		}
	}
	
	// recent orders
	getRecentOrders() {
		
		let query = json.container.leftSegment.components[0].options.query;
		
		let startTime = 201903181931;//dateFormat(new Date(), "yyyymmddHHMM");
		let sorterId = this.props.sorterId;
		
		fetch(graphQlURLPrd, {
			method: 'POST',
			headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json',
			},
			body: JSON.stringify({
				query,
				variables: { startTime, sorterId }
			})
		})
		.then(r => r.json())
		.then(data => {     this.setState({ value: data.data.getSorterCurrentRuntime,
				   			isLoading:false}); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ value: "",
				   			isLoading:false
						 }); 
		});
	}
	
	render() {
	
		const { isColorBlind } = this.props;		
		
		if(this.state.isLoading){
			return (<RctCollapsibleCard	colClasses="col-md-4 col-xl-4 col-sm-4 col-ls-4 left-align wave-status-area-height"
										fullBlock > 
							<Spinner />
					</RctCollapsibleCard>);
		} else {
			return (
					<RctCollapsibleCard
					colClasses="col-md-4 col-xl-4 col-sm-4 col-ls-4 left-align wave-status-area-height"
					>
						<div className="text-center">
							<img style={imageRuntime} src={Runtime} />
						</div>
						<div className="text-center" style={textStyle}>
							{<IntlMessages id={`indvlSoterDashbrd.Runtime`} />}
						</div>
						
						{isColorBlind ? (
							<div className="text-center" style={hrsStyleCB}>
							{this.state.value}
							</div>
						) : (
							<div className="text-center" style={hrsStyle}>
							{this.state.value}
						</div>
						)}
					</RctCollapsibleCard>
					);	
		}

	}
}

// map state to props
// Here we can fetch the value of isColorBlind as props
const mapStateToProps = ({ settings }) => {
	const { isColorBlind ,locale} = settings;
	//console.log("isColorBlind value inside mapstateToProps -- "+ isColorBlind);
	return { isColorBlind,locale };
};


export default withRouter(connect(mapStateToProps)(index));